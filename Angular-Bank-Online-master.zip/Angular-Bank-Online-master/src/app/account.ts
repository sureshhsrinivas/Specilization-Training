export class Account{
    
    constructor()
    {
   
    }
        accountType:string;
        accountNumber:number;
        accountBalance:number;
        customerId:number;
        lastTransactionDate:string;
        dateTransactionsCount:number;
    
    
   }