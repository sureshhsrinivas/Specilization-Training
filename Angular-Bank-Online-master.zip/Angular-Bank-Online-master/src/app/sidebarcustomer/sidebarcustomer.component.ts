import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebarcustomer',
  templateUrl: './sidebarcustomer.component.html',
  styleUrls: ['./sidebarcustomer.component.css']
})
export class SidebarcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
