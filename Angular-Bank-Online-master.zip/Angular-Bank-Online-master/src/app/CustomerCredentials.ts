export class CustomerCredentials{
    constructor()
    {
   
    }
    customerId:number;
        password:string;
   }