export class ILogin {
    userid: string;
    password: string;
    isLoggedIn:boolean;
    token:string
}