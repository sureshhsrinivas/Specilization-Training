import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankerhome',
  templateUrl: './bankerhome.component.html',
  styleUrls: ['./bankerhome.component.css']
})
export class BankerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
