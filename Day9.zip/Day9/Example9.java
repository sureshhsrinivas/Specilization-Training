import java.util.Date;

public class Example9 {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println("Todays date is "+date);
    }
}
