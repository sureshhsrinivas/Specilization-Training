import java.util.HashMap;
import java.util.Map;

public class HashMapEx1 {
    public static void main(String[] args) {
        Map<String,Integer> nuberMapping;
        nuberMapping= new HashMap<String,Integer>();
        nuberMapping.put("one",1);
        nuberMapping.put("Two",2);
        nuberMapping.put("Three",3);
        System.out.println(nuberMapping);

    }
}
