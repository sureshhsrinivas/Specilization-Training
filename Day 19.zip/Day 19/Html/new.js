function abc()
{
    console.log('hello');
    this.name= "This is demo text";
    console.log(this.name);
    console.log(this.name.toLocaleLowerCase());
    console.log(this.name.toLocaleUpperCase());
    this.name=this.name.concat(' welcome');
    console.log(this.name);
    console.log(this.name.slice(0,18));
    console.log(this.name.substring(8,18));
    console.log(this.name.substr(7,10));
    this.name= this.name.replace('demo','DEMO');
    console.log(this.name);
    console.log(this.name.lastIndexOf('DEMO'));
    console.log(this.name.startsWith('This'));
    console.log(this.name.endsWith('welcome'));
}

//abc();

var cars=["Hundai","Tata","Rang over","BMW"];
cars[4]="Audi";
cars.push("Santro");
cars[1]="I20"; // remove the element in index 1 and replace it
cars.pop();
for(var i=0; i<cars.length;i++){
    console.log(cars[i]);
}
console.log('----------------------');
var fruits = new Array();
fruits[0]="banana";
fruits[1]="apple";
fruits[2]="grapes";
for(const items of fruits){
    console.log(items);
}
console.log('----------------------');
for(const items in fruits){
    console.log(items);
}
console.log('----------------------');
console.log(fruits.sort());
console.log(fruits.sort().reverse());
fruits.sort();
for(const items of fruits){
    console.log(items);
}
console.log('----------------------');
var date= new Date();
console.log(date);
console.log(date.getDate());
console.log(date.getFullYear());
console.log("Time "+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds());
console.log(date.getUTCDate());
console.log('----------------------');
console.log('----------------------');
var date1= new Date("2021-03-25T12:01:00");
console.log(date1);
console.log(date1.getDate());
console.log(date1.getFullYear());
console.log("Time "+date1.getHours()+':'+date1.getMinutes()+':'+date1.getSeconds());
console.log(date1.getUTCDate());
console.log('----------------------');
