module.exports = {
  purge: [],
  theme: {
    extend: {
      colors: {
        navy: '#2f3458',
      },
    },
  },
  variants: {},
  plugins: [],
}
