# Angular 9 + Tailwind CSS banking app

This is app for the Duomly Angular 9 Course - Learn Angular 9 by building banking App

## Install

Install node modules using npm or yarn:

```bash
npm install
```

## Run

To start the application use:
```python
ng serve
```