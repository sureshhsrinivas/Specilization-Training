public class Emp {
    String name;
    int age;
    int salary;
    String designation;

    public Emp(String name, int age, int salary, String designation) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
    }

    public Emp() {

    }
}
