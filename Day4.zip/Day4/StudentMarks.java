public class StudentMarks {
    private String stdName;
    private int stdId;
    private String dept;
    private int Engmarks;
    private  int mathsmarks;
    private  int kannadamarks;
}
