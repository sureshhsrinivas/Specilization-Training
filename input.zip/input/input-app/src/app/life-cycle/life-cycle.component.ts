import { Component, DoCheck, OnChanges, OnInit, SimpleChange, SimpleChanges } from '@angular/core';

@Component({
  selector: 'life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit ,DoCheck,OnChanges{

  constructor() {
    console.log('Component is initilized');
   }
  ngDoCheck(): void {
    console.log('ngDocheck is called');
  }

   ngOnChanges(_changes: SimpleChanges): void{
     console.log('onchange method is called.....'+_changes);
     
   }
  ngOnInit(): void {
    console.log('init methos is called');
  }

}
