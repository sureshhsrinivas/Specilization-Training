public class ArrayExample {
    public static void main(String[] args) {
        int salaries[] = {500, 700,900,400,300,200};
        for(int i=0;i< salaries.length;i++){
            System.out.println("The elements at index"+i+"has the values of"+salaries[i]);
        }
    }
}
