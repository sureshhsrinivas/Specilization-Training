import { TransactionSearchPipe } from './transaction-search.pipe';

describe('TransactionSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new TransactionSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
