import { BeneficiarySearchPipe } from './beneficiary-search.pipe';

describe('BeneficiarySearchPipe', () => {
  it('create an instance', () => {
    const pipe = new BeneficiarySearchPipe();
    expect(pipe).toBeTruthy();
  });
});
