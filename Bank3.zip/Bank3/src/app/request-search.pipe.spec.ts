import { RequestSearchPipe } from './request-search.pipe';

describe('RequestSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new RequestSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
