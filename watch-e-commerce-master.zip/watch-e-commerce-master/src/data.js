export const storeProducts = [
  {
    id: 1,
    title: "Apple Watch Series 3",
    img: "/img1/product-1.png",
    price: 20000,
    company: "APPLE",
    info:
     "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 2,
    title: "Fastrack Chronograph",
    img: "/img1/product-2.png",
    price: 5300,
    company: "FASTRACK",
    info:
     "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 3,
    title: "Tommy Hilfiger - Analogue",
    img: "/img1/product-3.png",
    price: 4500,
    company: "TOMMY HILFIGER",
    info:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 4,
    title: "U.S Polo Assn.",
    img: "/img1/product-4.png",
    price: 4000,
    company: "U.S POLO ASSN.",
    info:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 5,
    title: "Casio Edifice Chronograph",
    img: "/img1/product-5.png",
    price: 5500,
    company: "CASIO",
    info:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 6,
    title: "MI Band 4",
    img: "/img1/product-6.png",
    price: 2300,
    company: "XIAOMI",
    info:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 7,
    title: "Fastrack Analogue",
    img: "/img1/product-7.png",
    price: 3500,
    company: "FASTRACK",
    info:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  },
  {
    id: 8,
    title: "Apple Watch Series 5",
    img: "/img1/product-8.png",
    price: 50000,
    company: "APPLE",
    info:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    inCart: false,
    count: 0,
    total: 0
  }
];
