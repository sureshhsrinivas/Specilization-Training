import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structural',
  templateUrl: './structural.component.html',
  styleUrls: ['./structural.component.css']
})
export class StructuralComponent implements OnInit {
  beverages=['tea','coffee','milk','juice'];
  json=[
    {'name':'thanu','age':'22','salary':24000},
    {'name':'priya','age':'22','salary':24000},
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
