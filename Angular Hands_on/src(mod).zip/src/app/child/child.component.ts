import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input("child")
  fruits:String='Apple';

  @Output() newFruit=new EventEmitter<String>();

  sendData(value:String){
  this.newFruit.emit(value);
  }
  
  
  constructor() { }

  ngOnInit(): void {
  }

}
