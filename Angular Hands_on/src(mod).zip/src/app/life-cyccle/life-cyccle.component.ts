import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-life-cyccle',
  templateUrl: './life-cyccle.component.html',
  styleUrls: ['./life-cyccle.component.css']
})
export class LifeCyccleComponent implements OnInit , DoCheck,OnChanges{
   constructor(){
     console.log('component initilized')
   }
  ngOnChanges(_changes: SimpleChanges): void {
    console.log('Onchange method is called..'+_changes);
  }
  ngOnInit(): void {
    console.log('Init method is called..');
  }

  ngDoCheck(): void {
    console.log('Docheck method is called..');
  }
 
}

