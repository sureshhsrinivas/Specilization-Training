import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LifeCyccleComponent } from './life-cyccle.component';

describe('LifeCyccleComponent', () => {
  let component: LifeCyccleComponent;
  let fixture: ComponentFixture<LifeCyccleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LifeCyccleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LifeCyccleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
