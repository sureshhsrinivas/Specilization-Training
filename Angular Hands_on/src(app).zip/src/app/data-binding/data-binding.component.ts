import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {

  uname:string='hello';
  city:string='banglore';
  myname='thanu';
  age='22'
  name='LTE';

  year='2000';

  source:any="assets/animal.jpg"
  height:number=400;
  wid:number=500;
  src='assets/simba.jpeg'
  enable:boolean=false;
  
  val:string='';
  tname:string='';
  constructor() { }

  ngOnInit(): void {
  }
  getDetails(){
    return `Hi this is ${this.name} and city ${this.city} and the year is ${this.year}`;
  }
  getData(){
    return `Hello this is ${this.myname} and im from  ${this.city} im ${this.age} this year`
  }
  demo(v:any,v2:any){
    this.val=`${v+' '+v2}`;
    // console.log(value);
  }
  twoway(a:any){
    this.tname=a;
  }
}
