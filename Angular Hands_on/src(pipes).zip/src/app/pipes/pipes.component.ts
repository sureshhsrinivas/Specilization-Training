import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
  name:string="Thanu Priya";
  DOB:Date=new Date();
  amount:number=24800;


  constructor() { }

  ngOnInit(): void {
  }

}
