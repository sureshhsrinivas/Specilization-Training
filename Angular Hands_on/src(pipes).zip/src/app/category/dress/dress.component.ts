import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dress',
  templateUrl: './dress.component.html',
  styleUrls: ['./dress.component.css']
})
export class DressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
