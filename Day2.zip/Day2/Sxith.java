import java.util.*;
import java.util.Scanner;
public class Sxith {
    public static void main(String[] args) {
        System.out.println("enter number");
        Scanner s = new Scanner(System.in);
        int num= s.nextInt();
        int fn=0;
        int ln=0;
        ln= num%10;
        while (num!=0){
            fn= num % 10;
            num/=10;
        }
        if(fn==ln){
            System.out.println("They are equal");
        }
        else
        {
            System.out.println("they are different");
        }


    }
}
