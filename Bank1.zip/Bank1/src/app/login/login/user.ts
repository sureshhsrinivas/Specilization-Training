export class User {

  constructor(
    public id?: string,
    public DOB?: string,
    public aadharNo?: number,
    public panNo?: string,
    public houseNo?: string,
    public district?: string,
    public state?: string,
    public country?: string,
    public password?: string,
    public amount?: string,) { }
}