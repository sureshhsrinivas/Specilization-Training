import { Payment } from './payment';

export class User {
    username: string;
    payment: Payment[];
}
