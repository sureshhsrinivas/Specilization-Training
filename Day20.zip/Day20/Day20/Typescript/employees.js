var v = {
    id: 1,
    name: " srini",
    city: "Bangalore",
    pincode: 560010,
    display: function () {
        console.log('demo text');
    }
};
console.log('Json implementation-----------------');
console.log("Name is " + v.name + " and city is " + v.city);
console.log("-------------------------");
var Manager = /** @class */ (function () {
    function Manager(id, name, city, pincode) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.pincode = pincode;
    }
    Manager.prototype.display = function () {
        console.log("Hii this is " + this.name + " and i am from " + this.city);
    };
    return Manager;
}());
var employee = new Manager(1, "srinivas", "bangalore", 560078);
employee.display();
console.log("-------------------------");
