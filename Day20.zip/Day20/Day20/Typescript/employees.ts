interface address{
    city: string;
    pincode: number;
}
interface Employees extends address{
    id: number;
    name: string;
    display?():void;

}
var v:Employees={
    id:1,
    name: " srini",
    city: "Bangalore",
    pincode: 560010,
    display:function():void{
        console.log('demo text');
    }
};
console.log('Json implementation-----------------');
console.log(`Name is ${v.name} and city is ${v.city}`);
console.log("-------------------------");
class Manager implements Employees{
    id: number;
    name: string;
    city: string;
    pincode: number;

    constructor(id: number, name:string,city:string,pincode:number){
        this.id=id;
        this.name=name;
        this.city= city;
        this.pincode=pincode;
    }
    display(): void {
        console.log(`Hii this is ${this.name} and i am from ${this.city}`);

    }
}
var employee:Manager = new Manager(1,"srinivas","bangalore",560078);
employee.display();
console.log("-------------------------");