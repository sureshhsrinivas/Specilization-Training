import{student} from'./student'
class principle extends student{
    constructor(id:number,name:string,marks:number){
        super(id,name,marks);
    }
}
var pp:principle= new principle(1,'srinivas',90);
console.log(pp.name);