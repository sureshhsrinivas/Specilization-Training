var array = ['apple', 1, 2, true, false, function () { return 'hello'; }, 10.12, new Date()];
console.log(array);
var arrays = [1, 2, 3, 4, 4, 4, 5, 5]; //here array can hold only number type of data
console.log(arrays);
for (var _i = 0, arrays_1 = arrays; _i < arrays_1.length; _i++) {
    var i = arrays_1[_i];
    console.log(i);
}
