/*class Student{
    id: number;
    name: String;
    marks: number;
    
    
    
    constructor(id : number,name : String,marks: number){
    this.id=id;
    this.name=name;
    this.marks=marks;
    }
    setId(id:number){
    this.id=id;
    }
    getId(): number{
    return this.id;
    }
    }
    var std=new student(1,'Srinivas',99);
    console.log(std.marks); */
    
    /*class Student{
        id: number;
        name: String;
        marks: number;
        
        
        
        constructor(id : number,name : String,marks: number){
        this.id=id;
        this.name=name;
        this.marks=marks;
        }
        setId(id:number){
        this.id=id;
        }
        getId(): number{
        return this.id;
        }
        
        
        
        verify(){
        if(this.marks>35){
        console.log('pass');
        }
        else{
        console.log('fail')
        }
        }
        }
        class teacher extends Student{
subject:String;
constructor(id : number,name : String,marks: number,subject :String){
super(id,name,marks);
this.subject=subject;
}
        
}  
        var std=new Student(1,'sri',90);
        std.verify(); 
*/
export class student{



    id:number;
    name:String;
    marks:number;
    constructor(id:number,name:String,marks:number){
    this.id = id;
    this.name = name;
    this.marks = marks;
    }
    
    
    
    
    verify():void{
    if(this.marks>= 35){
    console.log(`Student name is ${this.name} and marks is ${this.marks}`);
    }
    else
    {
    console.log('Fail');
    }
    }}
    class Teacher extends student{
    subject:String;
    constructor(id:number,name:String,marks:number,subject:String){
    super(id,name,marks);
    this.subject = subject;
    }
    }
    var std:student=new Teacher(1,'sonu',89,'Maths');
    std.verify()