var emp = { 'name': 'srinivas', 'age': 22, 'salary': 80000, 'city': 'bangalore' }; // here the object or interface is invoked
console.log(emp.name);
console.log(emp.city);
var e = { 'name': 'sanju', 'age': 22, 'salary': 200000 }; //this will invoke interface variables canot add anyother variable
//it will accept any variables
var e2 = { 'name': 'arun', 'age': 27,
    display: function () {
        return "Hi this is text demo";
    } }; //here the salary variable is optional
console.log("-----------------");
console.log("Employee Name " + e.name);
console.log("Employee Age " + e.age);
console.log("Employee Salary " + e.name);
console.log("-----------------");
console.log("Employee Name " + e2.name);
console.log("Employee Age " + e2.age);
console.log("Employee Salary " + e2.name);
console.log("Employee detais " + e2.display());
console.log("-----------------");
