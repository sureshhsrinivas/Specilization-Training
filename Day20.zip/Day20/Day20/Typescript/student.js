"use strict";
/*class Student{
    id: number;
    name: String;
    marks: number;
    
    
    
    constructor(id : number,name : String,marks: number){
    this.id=id;
    this.name=name;
    this.marks=marks;
    }
    setId(id:number){
    this.id=id;
    }
    getId(): number{
    return this.id;
    }
    }
    var std=new student(1,'Srinivas',99);
    console.log(std.marks); */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
/*class Student{
    id: number;
    name: String;
    marks: number;
    
    
    
    constructor(id : number,name : String,marks: number){
    this.id=id;
    this.name=name;
    this.marks=marks;
    }
    setId(id:number){
    this.id=id;
    }
    getId(): number{
    return this.id;
    }
    
    
    
    verify(){
    if(this.marks>35){
    console.log('pass');
    }
    else{
    console.log('fail')
    }
    }
    }
    class teacher extends Student{
subject:String;
constructor(id : number,name : String,marks: number,subject :String){
super(id,name,marks);
this.subject=subject;
}
    
}
    var std=new Student(1,'sri',90);
    std.verify();
*/
var student = /** @class */ (function () {
    function student(id, name, marks) {
        this.id = id;
        this.name = name;
        this.marks = marks;
    }
    student.prototype.verify = function () {
        if (this.marks >= 35) {
            console.log("Student name is " + this.name + " and marks is " + this.marks);
        }
        else {
            console.log('Fail');
        }
    };
    return student;
}());
exports.student = student;
var Teacher = /** @class */ (function (_super) {
    __extends(Teacher, _super);
    function Teacher(id, name, marks, subject) {
        var _this = _super.call(this, id, name, marks) || this;
        _this.subject = subject;
        return _this;
    }
    return Teacher;
}(student));
var std = new Teacher(1, 'sonu', 89, 'Maths');
std.verify();
