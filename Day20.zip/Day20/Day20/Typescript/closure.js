var count=0;
function demo(){
    count+=1;
    return count;
   
}
console.log(demo());
console.log(demo());
console.log(demo());
console.log(demo());
console.log("-------------------------");
function demo1(){
   
    var num=0;
    num+=1;
    return num;
}
console.log(demo1());
console.log(demo1());
console.log(demo1());
console.log(demo1());
console.log("-------------------------");
var demo2=(
    function(){
    let count=0;
    return function(){
        count+=1;
        return count;
    }
 }
 )();
console.log(demo2());
console.log(demo2());
console.log(demo2());
console.log(demo2());

console.log("-------------------------");
console.log("self invoking function");
(function(){console.log('self invoke')})();//self invoking
(()=>{console.log('arrow function')})();
((a)=>{console.log('arrow function '+a); return a})(10);
((a)=>{console.log('arrow function '+a)})(10);
var b=((a)=>{console.log('arrow function '+a); return a})(10);
var c=b;
console.log(c);