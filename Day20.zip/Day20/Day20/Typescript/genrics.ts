let array= ['apple',1,2,true,false,()=>{ return 'hello'},10.12, new Date()];
console.log(array);
let arrays:Array<number>=[1,2,3,4,4,4,5,5];//here array can hold only number type of data
console.log(arrays);
for(const i of arrays){
    console.log(i);
}