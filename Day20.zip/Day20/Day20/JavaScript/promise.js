/*var pr=new Promise((resolve,reject)=>{ 
    var condition=false;
    if(condition){
        console.log('condition fulfilled');
        resolve();
    }
    else{
        console.log('condition failed');
        reject();
    }
  });
  pr.then(success).catch(failure)
//pr.then(success,failure);
function success(){
    console.log('promise is succesful');
}
function failure(){
    console.log('promise is  not succesful');
}
 /* resolve()
  {

  }
  reject()
  {

  }*/
  console.log("-----------------");
  var pr1=new Promise((resolve,reject)=>{ 
    var condition= true;
    if(condition){
        console.log('Enter pin is proper');
        resolve('succesful money is withdraw');
    }
    else{
        console.log('Insufficient funds!......');
        reject('Amount is greater than balance');
    }
  });
  pr1.then(success1).catch(failures).finally(def);
//pr.then(success,failure);
function success1(msg1){
    console.log('promise is succesful');
    console.log(msg1);
}
function failures(msg1){
    console.log('promise is not succesful');
    console.log(msg1);
}
function def(){
    console.log('finally block executed');
}
console.log("-----------------");
//pending
//fulfiled
//reject


console.log("-----------------");