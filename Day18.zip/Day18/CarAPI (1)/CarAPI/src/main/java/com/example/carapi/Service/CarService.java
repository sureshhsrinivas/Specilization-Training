package com.example.carapi.Service;

import com.example.carapi.Model.Car;
import com.example.carapi.Repo.CarRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {

    @Autowired
    CarRepo repo;
    public void postCreate(Car car)
    {

        repo.save(car);
    }

    public List<Car>getCars()
    {
        List<Car> list=repo.findAll();
        return list;
    }
    public Car getCarById(int id)
    {
        Car car=repo.findById(id).orElse(new Car());
        return car;
    }

    public void deleteById(int id)
    {
        repo.deleteById(id);
    }
}
