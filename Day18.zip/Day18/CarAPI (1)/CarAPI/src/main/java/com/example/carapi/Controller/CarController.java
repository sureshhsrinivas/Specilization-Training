package com.example.carapi.Controller;

import com.example.carapi.Model.Car;
import com.example.carapi.Service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CarController
{
    @Autowired
    CarService service;

    @PostMapping(value = "/Create", consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Car>create(@RequestBody Car car)
    {
        service.postCreate(car);
        return new ResponseEntity<Car>(car,HttpStatus.CREATED);
    }
    @GetMapping(value="/Cars",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Car>>cars()
    {
        List<Car>list = service.getCars();
        return new ResponseEntity<List<Car>>(list,HttpStatus.CREATED);

    }
    @GetMapping(value="/Car/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Car>getCar(@PathVariable("id") int id)
    {
        Car car=service.getCarById(id);
        return new ResponseEntity<Car>(car,HttpStatus.CREATED);
    }
    @PutMapping(value="update",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Car>update(@RequestBody Car car)
    {
        service.postCreate(car);
        return new ResponseEntity<Car>(car,HttpStatus.CREATED);
    }

    @DeleteMapping(value="delete/{id}",consumes = MediaType.APPLICATION_JSON_VALUE)
        public ResponseEntity<String>deletebyId(@PathVariable("id") int id)
        {
            service.deleteById(id);
            return new ResponseEntity<String>("record deleted",HttpStatus.CREATED);
        }

}




